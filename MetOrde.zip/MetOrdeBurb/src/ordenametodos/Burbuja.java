
package ordenametodos;

public class Burbuja {
    
    public void ordenar(int arreglo[])
    {
        for(int i = 0; i < arreglo.length - 1; i++)
        {
            for(int j = 0; j < arreglo.length - 1; j++)
            {
                if (arreglo[j] > arreglo[j + 1])//Ordenamiento Ascendente o Descendente según operador: > ó <
                {
                    int temporal = arreglo[j+1];
                    arreglo[j+1] = arreglo[j];
                    arreglo[j] = temporal;
                }
            }
        }
        for(int i = 0;i < arreglo.length; i++)
        {
            System.out.println(arreglo[i]);
        }
    }
    
    
}
