
package ordenametodos;
import java.util.Arrays;

public class MetodosOrdenamiento {
    
    public static void main(String[] args){
        
        int arreglo[] = {23,24,10,101,5,6,50,2017,11,19,2};
        System.out.println("");
        System.out.println("Un vector tiene los siguientes elementos: "+Arrays.toString(arreglo)); //imprimir la matriz como una cadena
        System.out.println("");
        System.out.println("****************VECTOR ORDENADO POR*****************");
        System.out.println("");
        
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>  Método de Burbuja");        
        Burbuja burbuja = new Burbuja();
        burbuja.ordenar(arreglo);
        System.out.println("");
        System.out.println("");
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>  Método QuickShort");
        QuickShort quick = new QuickShort();
        quick.ordenarquicksort(arreglo);        
        for(int i=0; i<arreglo.length; i++)
        {
             System.out.println(arreglo[i]);
        }
        System.out.println("");
        System.out.println("");
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>  Método ShellShort");
        ShellShort shell = new ShellShort();
        shell.ordenar(arreglo);
        
    }//Fin Main
}//Fin Clase
